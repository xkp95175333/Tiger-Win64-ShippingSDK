// BlueprintGeneratedClass DA_WeatherScenarioLightning.DA_WeatherScenarioLightning_C
// Size: 0x70 (Inherited: 0x70)
struct UDA_WeatherScenarioLightning_C : UDA_WeatherScenario_C {
};

