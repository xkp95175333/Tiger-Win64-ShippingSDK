// BlueprintGeneratedClass TBP_Buff_Trap.TBP_Buff_Trap_C
// Size: 0x280 (Inherited: 0x280)
struct UTBP_Buff_Trap_C : UTigerBuffDOT {
};

