// UserDefinedEnum TBE_StatusIcon.TBE_StatusIcon
enum class TBE_StatusIcon : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	NewEnumerator5,
	NewEnumerator6,
	TBE_MAX,
};

