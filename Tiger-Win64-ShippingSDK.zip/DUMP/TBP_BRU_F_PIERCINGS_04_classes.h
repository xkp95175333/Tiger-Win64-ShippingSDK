// BlueprintGeneratedClass TBP_BRU_F_PIERCINGS_04.TBP_BRU_F_PIERCINGS_04_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_F_PIERCINGS_04_C : UTBP_PiercingSetCustomization_Master_C {
};

