// BlueprintGeneratedClass TBP_Buff_RejuvenatingVoice.TBP_Buff_RejuvenatingVoice_C
// Size: 0x278 (Inherited: 0x270)
struct UTBP_Buff_RejuvenatingVoice_C : UTigerBuffRejuvenatingVoice {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)

	void OnHealStop(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_RejuvenatingVoice.TBP_Buff_RejuvenatingVoice_C.OnHealStop // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnHealStart(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_RejuvenatingVoice.TBP_Buff_RejuvenatingVoice_C.OnHealStart // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnDeactivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_RejuvenatingVoice.TBP_Buff_RejuvenatingVoice_C.OnDeactivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_Buff_RejuvenatingVoice(int32_t EntryPoint); // Function TBP_Buff_RejuvenatingVoice.TBP_Buff_RejuvenatingVoice_C.ExecuteUbergraph_TBP_Buff_RejuvenatingVoice // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

