// BlueprintGeneratedClass TBP_AnimMetaData_StopIsActive.TBP_AnimMetaData_StopIsActive_C
// Size: 0x28 (Inherited: 0x28)
struct UTBP_AnimMetaData_StopIsActive_C : UAnimMetaData {
};

