// BlueprintGeneratedClass BPI_PlayerBuffs.BPI_PlayerBuffs_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_PlayerBuffs_C : UInterface {

	void IncrementFeedingBloodIndex(); // Function BPI_PlayerBuffs.BPI_PlayerBuffs_C.IncrementFeedingBloodIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

