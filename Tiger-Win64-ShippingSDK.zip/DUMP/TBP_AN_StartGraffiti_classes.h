// BlueprintGeneratedClass TBP_AN_StartGraffiti.TBP_AN_StartGraffiti_C
// Size: 0x38 (Inherited: 0x38)
struct UTBP_AN_StartGraffiti_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function TBP_AN_StartGraffiti.TBP_AN_StartGraffiti_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x16a87a0
};

