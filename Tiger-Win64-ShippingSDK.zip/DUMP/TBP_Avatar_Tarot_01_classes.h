// BlueprintGeneratedClass TBP_Avatar_Tarot_01.TBP_Avatar_Tarot_01_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Tarot_01_C : UTigerCharacterIconCustomization {
};

