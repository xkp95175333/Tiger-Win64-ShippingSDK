// BlueprintGeneratedClass TBP_BodyType_Bru_M.TBP_BodyType_Bru_M_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_BodyType_Bru_M_C : UTigerCharacterBodyTypeCustomization {
};

