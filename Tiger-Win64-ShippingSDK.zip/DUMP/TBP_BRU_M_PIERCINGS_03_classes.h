// BlueprintGeneratedClass TBP_BRU_M_PIERCINGS_03.TBP_BRU_M_PIERCINGS_03_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_M_PIERCINGS_03_C : UTBP_PiercingSetCustomization_Master_C {
};

