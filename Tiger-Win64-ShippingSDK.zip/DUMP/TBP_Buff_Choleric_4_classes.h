// BlueprintGeneratedClass TBP_Buff_Choleric_4.TBP_Buff_Choleric_3_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Choleric_3_C : UTigerBuff {
};

