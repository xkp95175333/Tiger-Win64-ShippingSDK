// BlueprintGeneratedClass BP_DecalBlood_Floor_01.BP_DecalBlood_Floor_01_C
// Size: 0x24c (Inherited: 0x228)
struct ABP_DecalBlood_Floor_01_C : AActor {
	struct UStaticMeshComponent* SM_Decal_Blood_Slaughterhouse_01; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	struct TArray<struct UStaticMesh*> Decal_Meshes; // 0x238(0x10)
	int32_t Decal_Selector; // 0x248(0x04)

	void UserConstructionScript(); // Function BP_DecalBlood_Floor_01.BP_DecalBlood_Floor_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

