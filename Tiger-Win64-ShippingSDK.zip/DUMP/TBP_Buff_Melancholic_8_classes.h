// BlueprintGeneratedClass TBP_Buff_Melancholic_8.TBP_Buff_Melancholic_7_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Melancholic_7_C : UTigerBuff {
};

