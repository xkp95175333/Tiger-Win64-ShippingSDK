// BlueprintGeneratedClass TBP_BRU_M_HEAD_02_SKINTONE_06.TBP_BRU_M_HEAD_02_SKINTONE_06_C
// Size: 0x160 (Inherited: 0x160)
struct UTBP_BRU_M_HEAD_02_SKINTONE_06_C : UTBP_SkinToneCustomization_Master_C {
};

