// BlueprintGeneratedClass TBP_Battlepass_HardCurrencyPack_Medium.TBP_Battlepass_HardCurrencyPack_Medium_C
// Size: 0x118 (Inherited: 0x118)
struct UTBP_Battlepass_HardCurrencyPack_Medium_C : UTBP_PremiumCurrency_Master_C {
};

