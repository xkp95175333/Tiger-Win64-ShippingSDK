// BlueprintGeneratedClass SL_Elysium_Toreador_Niklas.SL_Elysium_Toreador_Niklas_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_Toreador_Niklas_C : ALevelScriptActor {
};

