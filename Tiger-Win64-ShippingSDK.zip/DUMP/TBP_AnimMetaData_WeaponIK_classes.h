// BlueprintGeneratedClass TBP_AnimMetaData_WeaponIK.TBP_AnimMetaData_WeaponIK_C
// Size: 0x2a (Inherited: 0x28)
struct UTBP_AnimMetaData_WeaponIK_C : UAnimMetaData {
	enum class ENUM_WeaponIKOverride LeftHandIK_Enum; // 0x28(0x01)
	enum class ENUM_WeaponIKOverride RightHandIK_Enum; // 0x29(0x01)
};

