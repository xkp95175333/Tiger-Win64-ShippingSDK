// AnimBlueprintGeneratedClass ABP_Civilian.ABP_Civilian_C
// Size: 0x3e80 (Inherited: 0x430)
struct UABP_Civilian_C : UTigerNpcAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_4; // 0x438(0xc0)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // 0x4f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // 0x520(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15; // 0x548(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_13; // 0x5c8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14; // 0x5f8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_12; // 0x678(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13; // 0x6a8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_11; // 0x728(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3; // 0x758(0xb0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3; // 0x808(0xa0)
	struct FTigerFilteredLayeredBlend TigerAnimGraphNode_FilteredLayeredBlending; // 0x8a8(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7; // 0x970(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_6; // 0x998(0x48)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer; // 0x9e0(0x98)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6; // 0xa78(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5; // 0xaa0(0x158)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xbf8(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3; // 0xc28(0xc0)
	char pad_CE8[0x8]; // 0xce8(0x08)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2; // 0xcf0(0x1e0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK; // 0xed0(0x1e0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6; // 0x10b0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_6; // 0x10d0(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot_5; // 0x10f0(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5; // 0x1138(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4; // 0x1160(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x12b8(0xa0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4; // 0x1358(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12; // 0x1380(0x80)
	struct FAnimNode_Slot AnimGraphNode_Slot_4; // 0x1400(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x1448(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot_3; // 0x15a0(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x15e8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x1740(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x1768(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x18c0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x18e8(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // 0x1930(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // 0x1958(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // 0x1980(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // 0x19a8(0x28)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_21; // 0x19d0(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11; // 0x1ad8(0x80)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_5; // 0x1b58(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_5; // 0x1b78(0x20)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_10; // 0x1b98(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2; // 0x1bc8(0xc0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10; // 0x1c88(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9; // 0x1d08(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // 0x1d88(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x1db8(0xc0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0x1e78(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x1ef8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // 0x1f78(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // 0x1fa8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x1fd0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x1ff8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x2020(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x2048(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x2070(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x2098(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x20c0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x20e8(0x80)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4; // 0x2168(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4; // 0x2188(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_20; // 0x21a8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_19; // 0x22b0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_18; // 0x23b8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_17; // 0x24c0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_16; // 0x25c8(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // 0x26d0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x2700(0x80)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3; // 0x2780(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3; // 0x27a0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_15; // 0x27c0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_14; // 0x28c8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_13; // 0x29d0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_12; // 0x2ad8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_11; // 0x2be0(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // 0x2ce8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x2d18(0x80)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0x2d98(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2; // 0x2db8(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10; // 0x2dd8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9; // 0x2ee0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8; // 0x2fe8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7; // 0x30f0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6; // 0x31f8(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x3300(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x3330(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x3350(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5; // 0x3370(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4; // 0x3478(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x3580(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x3688(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x3790(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x3898(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x3918(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x3948(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x39c8(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x39f8(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x3a98(0x80)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot; // 0x3b18(0x90)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x3ba8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x3bf0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x3c20(0xb0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x3cd0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x3d00(0xb0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x3db0(0x28)
	bool bIsDedicatedServer; // 0x3dd8(0x01)
	char pad_3DD9[0x3]; // 0x3dd9(0x03)
	struct FVector LeftFootstepPosition; // 0x3ddc(0x0c)
	float LeftFootstepTime; // 0x3de8(0x04)
	float RightFootstepTime; // 0x3dec(0x04)
	struct FVector RightFootstepPosition; // 0x3df0(0x0c)
	struct FRotator CharacterRotation; // 0x3dfc(0x0c)
	float YawDelta; // 0x3e08(0x04)
	float DeltaX; // 0x3e0c(0x04)
	float YawDeltaSmooth; // 0x3e10(0x04)
	bool IsBeingFeedOn; // 0x3e14(0x01)
	bool IsRecovering; // 0x3e15(0x01)
	bool FullyRecoverd; // 0x3e16(0x01)
	bool InContextIdle; // 0x3e17(0x01)
	struct FName CachedContextBasedIdle; // 0x3e18(0x08)
	bool IsHoldingProp; // 0x3e20(0x01)
	char pad_3E21[0x3]; // 0x3e21(0x03)
	struct FName FaceAnimSlotName_00; // 0x3e24(0x08)
	struct FName FaceAnimSlotName_01; // 0x3e2c(0x08)
	struct FName FaceAnimSlotName_02; // 0x3e34(0x08)
	struct FName FaceAnimSlotName_03; // 0x3e3c(0x08)
	struct FRotator LookAtSpineRotator; // 0x3e44(0x0c)
	struct FRotator LookAtHeadRotator; // 0x3e50(0x0c)
	float LookAtVertical; // 0x3e5c(0x04)
	float LookAtHorizontal; // 0x3e60(0x04)
	float LookAtHorizontalSlow; // 0x3e64(0x04)
	float AimYawDelta; // 0x3e68(0x04)
	float Speed_Smooth; // 0x3e6c(0x04)
	struct TArray<struct UAnimMontage*> React Montage; // 0x3e70(0x10)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_Civilian.ABP_Civilian_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void AddEmotionalAnimationSet(struct UTigerAnimationSetCollection* InSetCollection); // Function ABP_Civilian.ABP_Civilian_C.AddEmotionalAnimationSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void Facial Animations(); // Function ABP_Civilian.ABP_Civilian_C.Facial Animations // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void StopCapMontage(enum class ETigerAIAnimationMode A); // Function ABP_Civilian.ABP_Civilian_C.StopCapMontage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void HandleContextualIdle(); // Function ABP_Civilian.ABP_Civilian_C.HandleContextualIdle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void HandleFootstepSound(float FootstepDuration, bool LeftFoot); // Function ABP_Civilian.ABP_Civilian_C.HandleFootstepSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_BBA6A9724AFCD837302A6AB8D3D55CBB(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_BBA6A9724AFCD837302A6AB8D3D55CBB // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_CA1CB30F44EF00F966251AAA867490CA(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_CA1CB30F44EF00F966251AAA867490CA // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_BlendListByBool_A6AB795945D148CB4AEE71AC2F76A9A2(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_BlendListByBool_A6AB795945D148CB4AEE71AC2F76A9A2 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_LayeredBoneBlend_D132CB474C4CD8732517EFAF61A0670E(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_LayeredBoneBlend_D132CB474C4CD8732517EFAF61A0670E // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_TigerAnimGraphNode_RandomPlayer_AD270F954A6AC11814CAFDA6C00BC755(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_TigerAnimGraphNode_RandomPlayer_AD270F954A6AC11814CAFDA6C00BC755 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_6D81CB9F40381D9D7F4CBA9295F53D55(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_6D81CB9F40381D9D7F4CBA9295F53D55 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_40147EBA4EB9F87484ECD1957842F4BC(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_40147EBA4EB9F87484ECD1957842F4BC // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_51FD1D124A1C5B0FA7BA3A8EFEF7A75A(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_51FD1D124A1C5B0FA7BA3A8EFEF7A75A // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_5E451A0047DDDB557C31CCA35B78D4C7(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_5E451A0047DDDB557C31CCA35B78D4C7 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_9765F80E4DF706EF633C41803692F608(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_9765F80E4DF706EF633C41803692F608 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_F0E4FE194236AF66FC2733AB7AF3FEEB(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_F0E4FE194236AF66FC2733AB7AF3FEEB // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_415DC49A4A4970B81DC471938308B791(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_415DC49A4A4970B81DC471938308B791 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_DEB4941343244C3724C4F6A3E966FCF0(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_DEB4941343244C3724C4F6A3E966FCF0 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_DDB556484047FAEBC14C5687AA7ED506(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_DDB556484047FAEBC14C5687AA7ED506 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_FF7B69DD43977067A7C8EAA305F7DE94(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_FF7B69DD43977067A7C8EAA305F7DE94 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_C2A09BAA45A8969D20CC9693267BE7A9(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_C2A09BAA45A8969D20CC9693267BE7A9 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A689E074CAAA0BCC42C20A2E224F2E6(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A689E074CAAA0BCC42C20A2E224F2E6 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_3B5B01C94F495AA698FAF9BA69180E2C(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_3B5B01C94F495AA698FAF9BA69180E2C // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_1410EC2340A6B877E3B6CFB8046D439A(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_1410EC2340A6B877E3B6CFB8046D439A // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_571FA2704A360D76B6518B88AB7AD669(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_571FA2704A360D76B6518B88AB7AD669 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_EA3BF44A4F4A3F201C36F0888B234655(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_EA3BF44A4F4A3F201C36F0888B234655 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_8DCA473E4F0442A438726E9DC0F181A8(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_8DCA473E4F0442A438726E9DC0F181A8 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_44626FDB45DD85C93968159051D3B35B(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_44626FDB45DD85C93968159051D3B35B // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_4D238E45428FCC9B6A39B0B930AC8AA4(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_4D238E45428FCC9B6A39B0B930AC8AA4 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A7EC1F94AABA14079965D87190BA410(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A7EC1F94AABA14079965D87190BA410 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_5E507CAD402D56D610FC95B131D51453(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_5E507CAD402D56D610FC95B131D51453 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_F680FFE542EA01E2748D7598FBD52DE5(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_F680FFE542EA01E2748D7598FBD52DE5 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_5500156C4CB9331DB2E91CA33F95F052(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_5500156C4CB9331DB2E91CA33F95F052 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_E1B0A8814539633E7C59898C4390A6CC(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_E1B0A8814539633E7C59898C4390A6CC // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_5B33898D4651D630534E489B77F5687C(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_5B33898D4651D630534E489B77F5687C // (BlueprintEvent) // @ game+0x16a87a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Civilian.ABP_Civilian_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnInitiateAnimationBlueprint(); // Function ABP_Civilian.ABP_Civilian_C.OnInitiateAnimationBlueprint // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void AddSets(struct UTigerAnimationSetCollection* SetCollection); // Function ABP_Civilian.ABP_Civilian_C.AddSets // (Event|Protected|BlueprintEvent) // @ game+0x16a87a0
	void AnimNotify_FootStep_Left(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_FootStep_Left // (BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void AnimNotify_Footstep_Right(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_Footstep_Right // (BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void OnFootstep(bool bIsLeftFoot, float FootstepDuration); // Function ABP_Civilian.ABP_Civilian_C.OnFootstep // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnNpcReactionEvent(struct FTigerNpcReactionEvent ReactionEvent); // Function ABP_Civilian.ABP_Civilian_C.OnNpcReactionEvent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void AnimNotify_FullyRecovered(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_FullyRecovered // (BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void AnimNotify_ResetFeedingState(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_ResetFeedingState // (BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void OnAnimationModeChanged(enum class ETigerAIAnimationMode LastAnimationMode); // Function ABP_Civilian.ABP_Civilian_C.OnAnimationModeChanged // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnBumpedByPlayerEvent(struct ATigerPlayer* InPlayer, struct FVector InDirectionToPlayer); // Function ABP_Civilian.ABP_Civilian_C.OnBumpedByPlayerEvent // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x16a87a0
	void OnSettle(struct FTigerSettleEvent SettleEvent); // Function ABP_Civilian.ABP_Civilian_C.OnSettle // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_ABP_Civilian(int32_t EntryPoint); // Function ABP_Civilian.ABP_Civilian_C.ExecuteUbergraph_ABP_Civilian // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

