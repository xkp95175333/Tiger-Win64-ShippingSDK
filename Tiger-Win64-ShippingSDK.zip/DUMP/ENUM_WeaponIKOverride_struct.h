// UserDefinedEnum ENUM_WeaponIKOverride.ENUM_WeaponIKOverride
enum class ENUM_WeaponIKOverride : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	ENUM_MAX,
};

