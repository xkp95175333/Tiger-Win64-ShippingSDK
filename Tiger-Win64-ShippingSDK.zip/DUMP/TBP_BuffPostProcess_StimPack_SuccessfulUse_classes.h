// BlueprintGeneratedClass TBP_BuffPostProcess_StimPack_SuccessfulUse.TBP_BuffPostProcess_StimPack_SuccessfulUse_C
// Size: 0x261 (Inherited: 0x261)
struct ATBP_BuffPostProcess_StimPack_SuccessfulUse_C : ATBP_BuffPostProcess_Master_C {
};

