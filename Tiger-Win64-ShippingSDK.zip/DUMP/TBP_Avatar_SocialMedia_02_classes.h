// BlueprintGeneratedClass TBP_Avatar_SocialMedia_02.TBP_Avatar_SocialMedia_02_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_SocialMedia_02_C : UTigerCharacterIconCustomization {
};

