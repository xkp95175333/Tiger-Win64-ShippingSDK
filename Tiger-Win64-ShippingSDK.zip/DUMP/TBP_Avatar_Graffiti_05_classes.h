// BlueprintGeneratedClass TBP_Avatar_Graffiti_05.TBP_Avatar_Graffiti_05_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Graffiti_05_C : UTigerCharacterIconCustomization {
};

