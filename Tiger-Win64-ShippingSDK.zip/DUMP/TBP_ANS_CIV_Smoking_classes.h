// BlueprintGeneratedClass TBP_ANS_CIV_Smoking.TBP_ANS_CIV_Smoking_C
// Size: 0x30 (Inherited: 0x30)
struct UTBP_ANS_CIV_Smoking_C : UAnimNotifyState {

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function TBP_ANS_CIV_Smoking.TBP_ANS_CIV_Smoking_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x16a87a0
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function TBP_ANS_CIV_Smoking.TBP_ANS_CIV_Smoking_C.Received_NotifyBegin // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x16a87a0
};

