// BlueprintGeneratedClass SL_Elysium_MainArea_Alice.SL_Elysium_MainArea_Alice_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_MainArea_Alice_C : ALevelScriptActor {
};

