// BlueprintGeneratedClass TBP_Buff_Phlegmatic_4.TBP_Buff_Phlegmatic_3_C
// Size: 0x278 (Inherited: 0x278)
struct UTBP_Buff_Phlegmatic_3_C : UTigerBuffHealthRegenBase {
};

