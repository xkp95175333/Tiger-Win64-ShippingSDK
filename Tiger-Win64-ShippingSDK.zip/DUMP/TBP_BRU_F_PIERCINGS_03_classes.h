// BlueprintGeneratedClass TBP_BRU_F_PIERCINGS_03.TBP_BRU_F_PIERCINGS_03_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_F_PIERCINGS_03_C : UTBP_PiercingSetCustomization_Master_C {
};

