// BlueprintGeneratedClass TBP_Buff_EarthShock_Stunned.TBP_Buff_EarthShock_Stunned_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_EarthShock_Stunned_C : UTigerBuff {
};

