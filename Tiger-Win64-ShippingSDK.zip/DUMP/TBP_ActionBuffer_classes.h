// BlueprintGeneratedClass TBP_ActionBuffer.TBP_ActionBuffer_C
// Size: 0xb0 (Inherited: 0xb0)
struct UTBP_ActionBuffer_C : UTigerActionBuffer {
};

