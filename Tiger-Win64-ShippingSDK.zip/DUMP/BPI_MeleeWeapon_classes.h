// BlueprintGeneratedClass BPI_MeleeWeapon.BPI_MeleeWeapon_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_MeleeWeapon_C : UInterface {

	void GetMeleeWeaponCategory(enum class ENUM_MeleeWeaponCategories MeleeWeaponCategory); // Function BPI_MeleeWeapon.BPI_MeleeWeapon_C.GetMeleeWeaponCategory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

