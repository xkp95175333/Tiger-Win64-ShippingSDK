// BlueprintGeneratedClass TBP_BeardCustomization_Master.TBP_BeardCustomization_Master_C
// Size: 0x150 (Inherited: 0x148)
struct UTBP_BeardCustomization_Master_C : UTigerCharacterBeardCustomization {
	struct UTBP_PoseableMesh_Master_C* PoseableMesh; // 0x148(0x08)
};

