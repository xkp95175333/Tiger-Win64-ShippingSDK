// UserDefinedEnum ENUM_RangedWeaponCategories.ENUM_RangedWeaponCategories
enum class ENUM_RangedWeaponCategories : uint8 {
	NewEnumerator30,
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator3,
	NewEnumerator4,
	NewEnumerator5,
	NewEnumerator6,
	NewEnumerator7,
	NewEnumerator10,
	NewEnumerator15,
	NewEnumerator22,
	NewEnumerator23,
	NewEnumerator27,
	NewEnumerator28,
	NewEnumerator29,
	NewEnumerator31,
	NewEnumerator32,
	ENUM_MAX,
};

