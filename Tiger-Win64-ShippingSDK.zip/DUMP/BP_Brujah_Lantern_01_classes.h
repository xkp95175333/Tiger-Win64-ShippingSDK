// BlueprintGeneratedClass BP_Brujah_Lantern_01.BP_Brujah_Lantern_01_C
// Size: 0x250 (Inherited: 0x228)
struct ABP_Brujah_Lantern_01_C : AActor {
	struct UStaticMeshComponent* SM_VFX_CandleFlame_02; // 0x228(0x08)
	struct UPointLightComponent* FlickeringLight1; // 0x230(0x08)
	struct UPointLightComponent* PointLight_02; // 0x238(0x08)
	struct UStaticMeshComponent* SM_Brujah_Lantern_01; // 0x240(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x248(0x08)

	void UserConstructionScript(); // Function BP_Brujah_Lantern_01.BP_Brujah_Lantern_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

