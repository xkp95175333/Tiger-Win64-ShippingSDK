// BlueprintGeneratedClass TBP_Buff_Choleric_3.TBP_Buff_Choleric_2_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Choleric_2_C : UTigerBuff {
};

