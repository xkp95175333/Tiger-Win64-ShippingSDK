// BlueprintGeneratedClass TBP_AxeThrow_Config.TBP_AxeThrow_Config_C
// Size: 0x1e0 (Inherited: 0x1e0)
struct UTBP_AxeThrow_Config_C : UTigerThrowingAxeConfig {
};

