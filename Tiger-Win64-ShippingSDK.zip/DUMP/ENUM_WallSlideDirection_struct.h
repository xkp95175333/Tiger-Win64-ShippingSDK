// UserDefinedEnum ENUM_WallSlideDirection.ENUM_WallSlideDirection
enum class ENUM_WallSlideDirection : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	ENUM_MAX,
};

