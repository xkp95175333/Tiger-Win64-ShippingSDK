// BlueprintGeneratedClass ML_Elysium.ML_Elysium_C
// Size: 0x238 (Inherited: 0x230)
struct AML_Elysium_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)

	void ReceiveBeginPlay(); // Function ML_Elysium.ML_Elysium_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x16a87a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function ML_Elysium.ML_Elysium_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_ML_Elysium(int32_t EntryPoint); // Function ML_Elysium.ML_Elysium_C.ExecuteUbergraph_ML_Elysium // (Final|UbergraphFunction) // @ game+0x16a87a0
};

