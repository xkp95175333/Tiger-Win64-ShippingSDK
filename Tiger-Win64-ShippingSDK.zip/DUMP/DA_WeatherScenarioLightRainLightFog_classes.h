// BlueprintGeneratedClass DA_WeatherScenarioLightRainLightFog.DA_WeatherScenarioLightRainLightFog_C
// Size: 0x70 (Inherited: 0x70)
struct UDA_WeatherScenarioLightRainLightFog_C : UDA_WeatherScenario_C {
};

