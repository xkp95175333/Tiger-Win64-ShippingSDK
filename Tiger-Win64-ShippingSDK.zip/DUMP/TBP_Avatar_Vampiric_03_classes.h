// BlueprintGeneratedClass TBP_Avatar_Vampiric_03.TBP_Avatar_Vampiric_03_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Vampiric_03_C : UTigerCharacterIconCustomization {
};

