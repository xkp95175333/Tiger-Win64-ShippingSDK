// UserDefinedEnum TBE_StatusBackground.TBE_StatusBackground
enum class TBE_StatusBackground : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	TBE_MAX,
};

