// BlueprintGeneratedClass TBP_BloodTrack_DragDropReorderOperation.TBP_BloodTrack_DragDropReorderOperation_C
// Size: 0x8c (Inherited: 0x88)
struct UTBP_BloodTrack_DragDropReorderOperation_C : UDragDropOperation {
	int32_t SourceIndex; // 0x88(0x04)
};

