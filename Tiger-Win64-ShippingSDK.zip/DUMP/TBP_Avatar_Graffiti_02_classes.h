// BlueprintGeneratedClass TBP_Avatar_Graffiti_02.TBP_Avatar_Graffiti_02_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Graffiti_02_C : UTigerCharacterIconCustomization {
};

