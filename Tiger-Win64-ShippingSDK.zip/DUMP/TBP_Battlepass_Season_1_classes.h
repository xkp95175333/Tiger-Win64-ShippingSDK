// BlueprintGeneratedClass TBP_Battlepass_Season_1.TBP_Battlepass_Season_0_C
// Size: 0x118 (Inherited: 0x118)
struct UTBP_Battlepass_Season_0_C : UTigerBattlepassItem {
};

