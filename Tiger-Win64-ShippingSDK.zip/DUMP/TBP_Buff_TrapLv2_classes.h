// BlueprintGeneratedClass TBP_Buff_TrapLv2.TBP_Buff_TrapLv2_C
// Size: 0x280 (Inherited: 0x280)
struct UTBP_Buff_TrapLv2_C : UTigerBuffDOT {
};

