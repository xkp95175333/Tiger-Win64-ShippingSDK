// BlueprintGeneratedClass BPI_RangedWeapon.BPI_RangedWeapon_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_RangedWeapon_C : UInterface {

	void GetRangedWeaponCategory(enum class ENUM_RangedWeaponCategories RangedWeaponCategory); // Function BPI_RangedWeapon.BPI_RangedWeapon_C.GetRangedWeaponCategory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

