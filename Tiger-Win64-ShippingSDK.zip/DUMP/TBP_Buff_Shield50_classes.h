// BlueprintGeneratedClass TBP_Buff_Shield50.TBP_Buff_Shield50_C
// Size: 0x290 (Inherited: 0x288)
struct UTBP_Buff_Shield50_C : UTigerBuffShieldAdrenalineRush {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)

	void OnActivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_Shield50.TBP_Buff_Shield50_C.OnActivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnDeactivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_Shield50.TBP_Buff_Shield50_C.OnDeactivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_Buff_Shield50(int32_t EntryPoint); // Function TBP_Buff_Shield50.TBP_Buff_Shield50_C.ExecuteUbergraph_TBP_Buff_Shield50 // (Final|UbergraphFunction) // @ game+0x16a87a0
};

