// BlueprintGeneratedClass I_ArchetypeSelectButton.I_ArchetypeSelectButton_C
// Size: 0x28 (Inherited: 0x28)
struct UI_ArchetypeSelectButton_C : UInterface {

	void SetIsDeselected(); // Function I_ArchetypeSelectButton.I_ArchetypeSelectButton_C.SetIsDeselected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void SetIsSelected(); // Function I_ArchetypeSelectButton.I_ArchetypeSelectButton_C.SetIsSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

