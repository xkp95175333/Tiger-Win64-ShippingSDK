// BlueprintGeneratedClass TBP_Buff_Melancholic_2.TBP_Buff_Melancholic_1_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Melancholic_1_C : UTigerBuff {
};

