// BlueprintGeneratedClass TBP_BRU_M_PIERCINGS_05.TBP_BRU_M_PIERCINGS_05_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_M_PIERCINGS_05_C : UTBP_PiercingSetCustomization_Master_C {
};

