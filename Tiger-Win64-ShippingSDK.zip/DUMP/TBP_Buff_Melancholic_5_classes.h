// BlueprintGeneratedClass TBP_Buff_Melancholic_5.TBP_Buff_Melancholic_4_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Melancholic_4_C : UTigerBuff {
};

