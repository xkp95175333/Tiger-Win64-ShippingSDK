// AnimBlueprintGeneratedClass ABP_VMP_NOS_F_HAIR_04_TEMP.ABP_VMP_NOS_F_HAIR_04_TEMP_C
// Size: 0x2f8 (Inherited: 0x2c0)
struct UABP_VMP_NOS_F_HAIR_04_TEMP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_VMP_NOS_F_HAIR_04_TEMP.ABP_VMP_NOS_F_HAIR_04_TEMP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_ABP_VMP_NOS_F_HAIR_04_TEMP(int32_t EntryPoint); // Function ABP_VMP_NOS_F_HAIR_04_TEMP.ABP_VMP_NOS_F_HAIR_04_TEMP_C.ExecuteUbergraph_ABP_VMP_NOS_F_HAIR_04_TEMP // (Final|UbergraphFunction) // @ game+0x16a87a0
};

