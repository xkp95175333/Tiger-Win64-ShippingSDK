// BlueprintGeneratedClass BPI_PingableActor.BPI_PingableActor_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_PingableActor_C : UInterface {

	void GetPingInfo(struct FTS_PingableActorInfo OutInfo); // Function BPI_PingableActor.BPI_PingableActor_C.GetPingInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void GetPingCategory(struct FName OutCategory); // Function BPI_PingableActor.BPI_PingableActor_C.GetPingCategory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

