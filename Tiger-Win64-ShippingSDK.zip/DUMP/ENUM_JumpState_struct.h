// UserDefinedEnum ENUM_JumpState.ENUM_JumpState
enum class ENUM_JumpState : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	ENUM_MAX,
};

