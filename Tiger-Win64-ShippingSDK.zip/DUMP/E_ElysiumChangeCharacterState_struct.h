// UserDefinedEnum E_ElysiumChangeCharacterState.E_ElysiumChangeCharacterState
enum class E_ElysiumChangeCharacterState : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	E_MAX,
};

