// BlueprintGeneratedClass Explosion_Test.Explosion_Test_C
// Size: 0x4d0 (Inherited: 0x4c0)
struct AExplosion_Test_C : ATigerAreaEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x4c8(0x08)

	void OnTriggerClient(); // Function Explosion_Test.Explosion_Test_C.OnTriggerClient // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_Explosion_Test(int32_t EntryPoint); // Function Explosion_Test.Explosion_Test_C.ExecuteUbergraph_Explosion_Test // (Final|UbergraphFunction) // @ game+0x16a87a0
};

