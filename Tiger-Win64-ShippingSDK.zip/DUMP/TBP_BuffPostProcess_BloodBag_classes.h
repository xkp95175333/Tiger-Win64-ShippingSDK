// BlueprintGeneratedClass TBP_BuffPostProcess_BloodBag.TBP_BuffPostProcess_BloodBag_C
// Size: 0x261 (Inherited: 0x261)
struct ATBP_BuffPostProcess_BloodBag_C : ATBP_BuffPostProcess_Master_C {

	void SetParameters(float NormalizedDuration); // Function TBP_BuffPostProcess_BloodBag.TBP_BuffPostProcess_BloodBag_C.SetParameters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

