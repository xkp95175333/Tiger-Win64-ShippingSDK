// BlueprintGeneratedClass TBP_Buff_Melancholic_3.TBP_Buff_Melancholic_2_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Melancholic_2_C : UTigerBuff {
};

