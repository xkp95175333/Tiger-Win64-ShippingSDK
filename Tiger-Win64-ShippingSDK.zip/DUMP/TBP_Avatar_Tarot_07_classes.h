// BlueprintGeneratedClass TBP_Avatar_Tarot_07.TBP_Avatar_Tarot_07_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Tarot_07_C : UTigerCharacterIconCustomization {
};

