// BlueprintGeneratedClass TBP_Buff_Sanguine_2.TBP_Buff_Sanguine_1_C
// Size: 0x278 (Inherited: 0x278)
struct UTBP_Buff_Sanguine_1_C : UTigerBuffHealthRegenBase {
};

