// BlueprintGeneratedClass TBP_BloodTrack_DragDropSelectPassiveOperation.TBP_BloodTrack_DragDropSelectPassiveOperation_C
// Size: 0x90 (Inherited: 0x88)
struct UTBP_BloodTrack_DragDropSelectPassiveOperation_C : UDragDropOperation {
	struct UTigerBloodTrackPassiveConfig* Passive; // 0x88(0x08)
};

