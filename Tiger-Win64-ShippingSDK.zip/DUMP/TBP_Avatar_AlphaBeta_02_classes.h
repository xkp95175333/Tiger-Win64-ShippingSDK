// BlueprintGeneratedClass TBP_Avatar_AlphaBeta_02.TBP_Avatar_AlphaBeta_02_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_AlphaBeta_02_C : UTigerCharacterIconCustomization {
};

