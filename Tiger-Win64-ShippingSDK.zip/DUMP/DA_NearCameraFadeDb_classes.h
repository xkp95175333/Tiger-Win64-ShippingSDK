// BlueprintGeneratedClass DA_NearCameraFadeDb.DA_NearCameraFadeDb_C
// Size: 0xd0 (Inherited: 0xd0)
struct UDA_NearCameraFadeDb_C : UTigerNearCameraFadeMaterialDb {
};

