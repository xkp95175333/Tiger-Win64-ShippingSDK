// AnimBlueprintGeneratedClass ABP_Vendor.ABP_Vendor_C
// Size: 0x22e4 (Inherited: 0x430)
struct UABP_Vendor_C : UTigerNpcAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x438(0x158)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // 0x590(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // 0x5b8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // 0x5e0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // 0x608(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // 0x630(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // 0x658(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // 0x680(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x6a8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x6d0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x6f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x720(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x748(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x770(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x798(0x28)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // 0x7c0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_16; // 0x7f0(0x80)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum; // 0x870(0xb0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15; // 0x920(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14; // 0x9a0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13; // 0xa20(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12; // 0xaa0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11; // 0xb20(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // 0xba0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10; // 0xbd0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // 0xc50(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9; // 0xc80(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0xd00(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0xd30(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0xdb0(0x30)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer_2; // 0xde0(0x98)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0xe78(0x30)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer; // 0xea8(0x98)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0xf40(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0xfe0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x1060(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x1090(0xb0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x1140(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x1200(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x1228(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x1270(0x28)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_5; // 0x1298(0xc8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1360(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x1380(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5; // 0x13a0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4; // 0x14a8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x15b0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x16b8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x17c0(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x18c8(0x28)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x18f0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x1920(0xb0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x19d0(0xa0)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x1a70(0xc8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x1b38(0x80)
	struct FAnimNode_PoseBlendNode AnimGraphNode_PoseBlendNode; // 0x1bb8(0xa0)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1c58(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x1c88(0x80)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_4; // 0x1d08(0xc8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x1dd0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x1e50(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1ed0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x1f50(0x80)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_3; // 0x1fd0(0xc8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2; // 0x2098(0xc8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x2160(0xc8)
	struct UTigerAnimationSetAsset* AnimationSet; // 0x2228(0x08)
	bool HasRandomisedIdle; // 0x2230(0x01)
	char pad_2231[0x3]; // 0x2231(0x03)
	float LookAtVertical; // 0x2234(0x04)
	float LookAtHorizontal; // 0x2238(0x04)
	float LookAtHorizontalSlow; // 0x223c(0x04)
	float DeltaX; // 0x2240(0x04)
	struct FRotator LookAtHeadRotator; // 0x2244(0x0c)
	struct FRotator LookAtSpineRotator; // 0x2250(0x0c)
	bool AnimLookAtAllowed; // 0x225c(0x01)
	bool HasGreeted; // 0x225d(0x01)
	char pad_225E[0x2]; // 0x225e(0x02)
	float LookAtTransSpeed; // 0x2260(0x04)
	struct FName FaceAnimSlotName_00; // 0x2264(0x08)
	struct FName FaceAnimSlotName_01; // 0x226c(0x08)
	struct FName FaceAnimSlotName_02; // 0x2274(0x08)
	struct FName FaceAnimSlotName_03; // 0x227c(0x08)
	enum class ETigerDialogueIdleAnimation IdleType; // 0x2284(0x01)
	bool HasIdleToLookAtAnim; // 0x2285(0x01)
	bool HasLookAtToIdleAnim; // 0x2286(0x01)
	char pad_2287[0x1]; // 0x2287(0x01)
	struct TMap<struct UActorComponent*, struct UTigerAnimationSetAsset*> NewVar_1; // 0x2288(0x50)
	bool IsInInteraction; // 0x22d8(0x01)
	bool CooldownOver; // 0x22d9(0x01)
	char pad_22DA[0x2]; // 0x22da(0x02)
	float DeltaTimer; // 0x22dc(0x04)
	float CooldownLenght; // 0x22e0(0x04)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_Vendor.ABP_Vendor_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void FacialAnimations(); // Function ABP_Vendor.ABP_Vendor_C.FacialAnimations // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_83BFD29343C675CCC5E52F96EEFD0D85(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_83BFD29343C675CCC5E52F96EEFD0D85 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_B83E6FD34416943E4F60A5854B25A772(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_B83E6FD34416943E4F60A5854B25A772 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_0BE017A94AE17BAAF196D89FD12072FC(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_0BE017A94AE17BAAF196D89FD12072FC // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_A25B43D14DBFD4A98DAF769F4C874773(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_A25B43D14DBFD4A98DAF769F4C874773 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_1D5342D0496446528003C09DBB269E06(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_1D5342D0496446528003C09DBB269E06 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TwoWayBlend_D37AF0384A4CC7B61365FCAC2705479F(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TwoWayBlend_D37AF0384A4CC7B61365FCAC2705479F // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_TigerAnimGraphNode_RandomPlayer_E1E4913B4DD3D5E80E701FA71626CA1F(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_TigerAnimGraphNode_RandomPlayer_E1E4913B4DD3D5E80E701FA71626CA1F // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_C6E46422441151CFB7DE73AE11808333(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_C6E46422441151CFB7DE73AE11808333 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_TigerAnimGraphNode_RandomPlayer_05DEA6EB4D8001B9C83DAA9859859362(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_TigerAnimGraphNode_RandomPlayer_05DEA6EB4D8001B9C83DAA9859859362 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_69A1CC994A59DAD9034DFD9F3CE92218(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_69A1CC994A59DAD9034DFD9F3CE92218 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_9F2D47874130037522611F899DBE65E1(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_9F2D47874130037522611F899DBE65E1 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_4F53982F4D8AFB04B882ED8B664577BC(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_4F53982F4D8AFB04B882ED8B664577BC // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_F9DE1C2A40644B4BE8FB408D4C4E30D8(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_F9DE1C2A40644B4BE8FB408D4C4E30D8 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_F1C9743D4274E76987CAF9946F09E55D(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_F1C9743D4274E76987CAF9946F09E55D // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_B8C1874C41DB4EF5800C2986E763C69C(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_B8C1874C41DB4EF5800C2986E763C69C // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_47AD4F924ACEAB369B558F8C88A0B045(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_47AD4F924ACEAB369B558F8C88A0B045 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_720622874B9BB55116BFC8BAFF52119B(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_720622874B9BB55116BFC8BAFF52119B // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_7AA39E4B4A811C4F5D8313828B169656(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_SequencePlayer_7AA39E4B4A811C4F5D8313828B169656 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_452C266742F2A56D76D96FAA41288FFF(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_452C266742F2A56D76D96FAA41288FFF // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_4077772F4C55BC1FCAFD05A4F4059FA1(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_4077772F4C55BC1FCAFD05A4F4059FA1 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_F832016349BE8D525619A0809B8F8B81(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_F832016349BE8D525619A0809B8F8B81 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_AD34B8E24C6E3140074A46A6D322EA05(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_AD34B8E24C6E3140074A46A6D322EA05 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_1B827D5246973FDD9CECFCA7FE4A7D17(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_1B827D5246973FDD9CECFCA7FE4A7D17 // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_5A33D1DB442E9E8EBEEFA98CAB18521E(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_5A33D1DB442E9E8EBEEFA98CAB18521E // (BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_269138D6434C5FAE9B12BAB4824A9F5C(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_269138D6434C5FAE9B12BAB4824A9F5C // (BlueprintEvent) // @ game+0x16a87a0
	void AddSets(struct UTigerAnimationSetCollection* SetCollection); // Function ABP_Vendor.ABP_Vendor_C.AddSets // (Event|Protected|BlueprintEvent) // @ game+0x16a87a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Vendor.ABP_Vendor_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_E832D8A24F77DFF7A08BD291D1ABC4F0(); // Function ABP_Vendor.ABP_Vendor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Vendor_AnimGraphNode_TransitionResult_E832D8A24F77DFF7A08BD291D1ABC4F0 // (BlueprintEvent) // @ game+0x16a87a0
	void AnimNotify_HasGreeted(); // Function ABP_Vendor.ABP_Vendor_C.AnimNotify_HasGreeted // (BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void OnInitiateAnimationBlueprint(); // Function ABP_Vendor.ABP_Vendor_C.OnInitiateAnimationBlueprint // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_ABP_Vendor(int32_t EntryPoint); // Function ABP_Vendor.ABP_Vendor_C.ExecuteUbergraph_ABP_Vendor // (Final|UbergraphFunction) // @ game+0x16a87a0
};

