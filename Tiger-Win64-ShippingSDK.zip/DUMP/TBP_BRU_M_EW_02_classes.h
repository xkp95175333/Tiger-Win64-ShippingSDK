// BlueprintGeneratedClass TBP_BRU_M_EW_02.TBP_BRU_M_EW_02_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UTBP_BRU_M_EW_02_C : UTBP_EyewearCustomization_Master_C {
};

