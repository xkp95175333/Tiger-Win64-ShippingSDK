// BlueprintGeneratedClass TBP_AnimMetaData_IsInPrimingAnim.TBP_AnimMetaData_IsInPrimingAnim_C
// Size: 0x28 (Inherited: 0x28)
struct UTBP_AnimMetaData_IsInPrimingAnim_C : UAnimMetaData {
};

