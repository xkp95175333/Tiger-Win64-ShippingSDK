// BlueprintGeneratedClass Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C
// Size: 0x4d0 (Inherited: 0x4c0)
struct ACrossbow_Gas_Cloud_3_C : ATigerAreaEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x4c8(0x08)

	void OnTriggerClient(); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.OnTriggerClient // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_Crossbow_Gas_Cloud_4(int32_t EntryPoint); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.ExecuteUbergraph_Crossbow_Gas_Cloud_4 // (Final|UbergraphFunction) // @ game+0x16a87a0
};

