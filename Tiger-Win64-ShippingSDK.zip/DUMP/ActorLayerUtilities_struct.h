// ScriptStruct ActorLayerUtilities.ActorLayer
// Size: 0x08 (Inherited: 0x00)
struct FActorLayer {
	struct FName Name; // 0x00(0x08)
};

