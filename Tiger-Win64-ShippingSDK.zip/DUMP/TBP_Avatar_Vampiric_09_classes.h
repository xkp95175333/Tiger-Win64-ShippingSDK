// BlueprintGeneratedClass TBP_Avatar_Vampiric_09.TBP_Avatar_Vampiric_09_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Vampiric_09_C : UTigerCharacterIconCustomization {
};

