// BlueprintGeneratedClass TBFL_SetPrimitiveData.TBFL_SetPrimitiveData_C
// Size: 0x28 (Inherited: 0x28)
struct UTBFL_SetPrimitiveData_C : UBlueprintFunctionLibrary {

	void SetPrimitiveData_M_Awnings_Master(struct UPrimitiveComponent* PrimitiveComponent, struct FVector AlbedoMultiplier, float EmissiveIntensity, float EmissiveLightTextureInfluence, float EmissiveBGTexture, struct UObject* __WorldContext); // Function TBFL_SetPrimitiveData.TBFL_SetPrimitiveData_C.SetPrimitiveData_M_Awnings_Master // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void SetPrimitiveData_M_Decal_Master(struct UPrimitiveComponent* PrimitiveComponent, struct FVector Color, float Alpha, float FakeIntensity, struct UObject* __WorldContext); // Function TBFL_SetPrimitiveData.TBFL_SetPrimitiveData_C.SetPrimitiveData_M_Decal_Master // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void SetPrimitiveData_MI_ShopWindGlass_01(struct UPrimitiveComponent* PrimitiveComponent, struct FVector Color1, struct FVector Color2, struct FVector Emissive Color, float Emissive Multiplier, struct UObject* __WorldContext); // Function TBFL_SetPrimitiveData.TBFL_SetPrimitiveData_C.SetPrimitiveData_MI_ShopWindGlass_01 // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void SetPrimitiveData_M_Basic_Master(struct UPrimitiveComponent* PrimitiveComponent, struct FVector Color1, struct FVector Color2, struct FVector2D UV Scale, struct FVector Emissive Color, float Roughness Offset, float Albedo Hue Shift, float Deffuse Desaturation, struct UObject* __WorldContext); // Function TBFL_SetPrimitiveData.TBFL_SetPrimitiveData_C.SetPrimitiveData_M_Basic_Master // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

