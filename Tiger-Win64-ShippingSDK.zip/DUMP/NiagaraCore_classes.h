// Class NiagaraCore.NiagaraMergeable
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraMergeable : UObject {
};

// Class NiagaraCore.NiagaraDataInterfaceBase
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraDataInterfaceBase : UNiagaraMergeable {
};

