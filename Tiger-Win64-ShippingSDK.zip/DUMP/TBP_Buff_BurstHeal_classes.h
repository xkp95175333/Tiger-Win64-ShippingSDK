// BlueprintGeneratedClass TBP_Buff_BurstHeal.TBP_Buff_BurstHeal_C
// Size: 0x27c (Inherited: 0x27c)
struct UTBP_Buff_BurstHeal_C : UTBP_Buff_Heal_C {
};

