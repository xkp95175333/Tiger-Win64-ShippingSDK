// BlueprintGeneratedClass TBP_Battlepass_SoftCurrencyPack_Small.TBP_Battlepass_SoftCurrencyPack_Small_C
// Size: 0x120 (Inherited: 0x120)
struct UTBP_Battlepass_SoftCurrencyPack_Small_C : UTBP_SoftCurrencyPack_Master_C {
};

