// BlueprintGeneratedClass TBP_Avatar_Tarot_08.TBP_Avatar_Tarot_08_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Tarot_08_C : UTigerCharacterIconCustomization {
};

