// BlueprintGeneratedClass TBP_AI_IsBloodDrainedDeco.TBP_AI_IsBloodDrainedDeco_C
// Size: 0xc8 (Inherited: 0xa0)
struct UTBP_AI_IsBloodDrainedDeco_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector Self Actor; // 0xa0(0x28)

	bool PerformConditionCheck(struct AActor* OwnerActor); // Function TBP_AI_IsBloodDrainedDeco.TBP_AI_IsBloodDrainedDeco_C.PerformConditionCheck // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

