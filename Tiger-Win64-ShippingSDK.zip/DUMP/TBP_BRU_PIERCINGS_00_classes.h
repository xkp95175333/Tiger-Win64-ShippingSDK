// BlueprintGeneratedClass TBP_BRU_PIERCINGS_00.TBP_BRU_PIERCINGS_00_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_PIERCINGS_00_C : UTBP_PiercingSetCustomization_Master_C {
};

