// UserDefinedEnum ENUM_MeleeWeaponCategories.ENUM_MeleeWeaponCategories
enum class ENUM_MeleeWeaponCategories : uint8 {
	NewEnumerator15,
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator10,
	NewEnumerator12,
	NewEnumerator11,
	ENUM_MAX,
};

