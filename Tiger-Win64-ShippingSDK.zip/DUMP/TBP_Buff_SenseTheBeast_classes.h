// BlueprintGeneratedClass TBP_Buff_SenseTheBeast.TBP_Buff_SenseTheBeast_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_SenseTheBeast_C : UTigerTrackedBuff {
};

