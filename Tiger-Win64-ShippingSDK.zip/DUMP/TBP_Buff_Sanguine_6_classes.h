// BlueprintGeneratedClass TBP_Buff_Sanguine_6.TBP_Buff_Sanguine_5_C
// Size: 0x278 (Inherited: 0x278)
struct UTBP_Buff_Sanguine_5_C : UTigerBuffHealthRegenBase {
};

