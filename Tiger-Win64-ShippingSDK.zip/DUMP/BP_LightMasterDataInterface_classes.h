// BlueprintGeneratedClass BP_LightMasterDataInterface.BP_LightMasterDataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_LightMasterDataInterface_C : UObject {

	void GetIESProfile(int32_t InIndex, struct UTextureLightProfile* OutIESProfile); // Function BP_LightMasterDataInterface.BP_LightMasterDataInterface_C.GetIESProfile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x16a87a0
	void GetLightMateriales(int32_t InIndex, struct UMaterialInstance* OutMaterial); // Function BP_LightMasterDataInterface.BP_LightMasterDataInterface_C.GetLightMateriales // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x16a87a0
	void GetLightMeshes(int32_t InIndex, struct UStaticMesh* OutMesh); // Function BP_LightMasterDataInterface.BP_LightMasterDataInterface_C.GetLightMeshes // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x16a87a0
	void GetLightFlickerMaterial(int32_t InIndex, struct UMaterialInstance* OutMaterial); // Function BP_LightMasterDataInterface.BP_LightMasterDataInterface_C.GetLightFlickerMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x16a87a0
	void GetLightOffMaterial(int32_t InIndex, struct UMaterialInstance* OutMaterial); // Function BP_LightMasterDataInterface.BP_LightMasterDataInterface_C.GetLightOffMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x16a87a0
};

