// BlueprintGeneratedClass TBP_BRU_F_HEADGEAR_01.TBP_BRU_F_HEADGEAR_01_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UTBP_BRU_F_HEADGEAR_01_C : UTBP_Headgear_Customization_Master_C {
};

