// BlueprintGeneratedClass SL_ElysiumGlobal.SL_ElysiumGlobal_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_ElysiumGlobal_C : ALevelScriptActor {
};

