// BlueprintGeneratedClass TBP_Buff_BlindingBeauty.TBP_Buff_BlindingBeauty_C
// Size: 0x280 (Inherited: 0x278)
struct UTBP_Buff_BlindingBeauty_C : UTigerBuffBlindingBeauty {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)

	void OnActivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_BlindingBeauty.TBP_Buff_BlindingBeauty_C.OnActivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_Buff_BlindingBeauty(int32_t EntryPoint); // Function TBP_Buff_BlindingBeauty.TBP_Buff_BlindingBeauty_C.ExecuteUbergraph_TBP_Buff_BlindingBeauty // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

