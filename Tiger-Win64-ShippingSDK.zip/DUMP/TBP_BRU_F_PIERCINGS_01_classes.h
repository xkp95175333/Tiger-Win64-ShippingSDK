// BlueprintGeneratedClass TBP_BRU_F_PIERCINGS_01.TBP_BRU_F_PIERCINGS_01_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_F_PIERCINGS_01_C : UTBP_PiercingSetCustomization_Master_C {
};

