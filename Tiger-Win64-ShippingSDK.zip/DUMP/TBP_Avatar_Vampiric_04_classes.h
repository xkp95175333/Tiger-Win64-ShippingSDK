// BlueprintGeneratedClass TBP_Avatar_Vampiric_04.TBP_Avatar_Vampiric_04_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_Avatar_Vampiric_04_C : UTigerCharacterIconCustomization {
};

