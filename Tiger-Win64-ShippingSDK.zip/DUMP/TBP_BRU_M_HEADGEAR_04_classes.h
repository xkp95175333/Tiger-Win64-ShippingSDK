// BlueprintGeneratedClass TBP_BRU_M_HEADGEAR_04.TBP_BRU_M_HEADGEAR_04_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UTBP_BRU_M_HEADGEAR_04_C : UTBP_Headgear_Customization_Master_C {
};

