// BlueprintGeneratedClass TBP_Buff_Choleric_7.TBP_Buff_Choleric_6_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Choleric_6_C : UTigerBuff {
};

