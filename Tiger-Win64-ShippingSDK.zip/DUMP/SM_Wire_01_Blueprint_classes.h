// BlueprintGeneratedClass SM_Wire_01_Blueprint.SM_Wire_01_Blueprint_C
// Size: 0x240 (Inherited: 0x228)
struct ASM_Wire_01_Blueprint_C : AActor {
	struct USplineComponent* Spline; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	struct USplineMeshComponent* Current Mesh; // 0x238(0x08)

	void UserConstructionScript(); // Function SM_Wire_01_Blueprint.SM_Wire_01_Blueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
};

