// BlueprintGeneratedClass TBP_BRU_F_PIERCINGS_02.TBP_BRU_F_PIERCINGS_02_C
// Size: 0x170 (Inherited: 0x170)
struct UTBP_BRU_F_PIERCINGS_02_C : UTBP_PiercingSetCustomization_Master_C {
};

