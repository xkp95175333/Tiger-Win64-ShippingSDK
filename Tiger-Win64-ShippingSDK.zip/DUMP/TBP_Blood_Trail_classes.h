// BlueprintGeneratedClass TBP_Blood_Trail.TBP_Blood_Trail_C
// Size: 0x280 (Inherited: 0x280)
struct UTBP_Blood_Trail_C : UTigerBuffDOT {
};

