// BlueprintGeneratedClass TBP_BeardColorCustomization_Master.TBP_BeardColorCustomization_Master_C
// Size: 0x150 (Inherited: 0x148)
struct UTBP_BeardColorCustomization_Master_C : UTigerCharacterBeardColorCustomization {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x148(0x08)

	struct UMaterialInterface* GetUiMaterialOverride(); // Function TBP_BeardColorCustomization_Master.TBP_BeardColorCustomization_Master_C.GetUiMaterialOverride // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void SetUIMaterialParameters(struct UMaterialInstanceDynamic* InMaterial); // Function TBP_BeardColorCustomization_Master.TBP_BeardColorCustomization_Master_C.SetUIMaterialParameters // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_BeardColorCustomization_Master(int32_t EntryPoint); // Function TBP_BeardColorCustomization_Master.TBP_BeardColorCustomization_Master_C.ExecuteUbergraph_TBP_BeardColorCustomization_Master // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

