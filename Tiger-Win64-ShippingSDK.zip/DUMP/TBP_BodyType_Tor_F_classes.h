// BlueprintGeneratedClass TBP_BodyType_Tor_F.TBP_BodyType_Tor_F_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_BodyType_Tor_F_C : UTigerCharacterBodyTypeCustomization {
};

