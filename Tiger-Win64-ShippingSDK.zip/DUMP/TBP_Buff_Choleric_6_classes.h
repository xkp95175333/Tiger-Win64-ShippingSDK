// BlueprintGeneratedClass TBP_Buff_Choleric_6.TBP_Buff_Choleric_5_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Choleric_5_C : UTigerBuff {
};

