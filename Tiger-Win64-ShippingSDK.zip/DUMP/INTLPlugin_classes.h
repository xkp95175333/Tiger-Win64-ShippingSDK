// Class INTLPlugin.INTLBaseUserWidget
// Size: 0x268 (Inherited: 0x260)
struct UINTLBaseUserWidget : UUserWidget {
	char pad_260[0x8]; // 0x260(0x08)
};

// Class INTLPlugin.INTLOutputUtility
// Size: 0x28 (Inherited: 0x28)
struct UINTLOutputUtility : UBlueprintFunctionLibrary {

	void FormatVerifyCodeStatusRet(struct FINTLVerifyCodeStatusResult Ret, bool IsSuccess, struct FText ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatVerifyCodeStatusRet // (Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbbf710
	void FormatNoticeRet(struct FINTLNoticeResult Ret, bool IsSuccess, struct FText ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatNoticeRet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbbf360
	void FormatBaseRet(struct FINTLBaseResult Ret, bool IsSuccess, struct FText ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatBaseRet // (Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbbf0e0
	void FormatAuthRet(struct FINTLAuthResult Ret, bool IsSuccess, struct FText ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatAuthRet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbbe9c0
};

// Class INTLPlugin.INTLPluginObserver
// Size: 0x28 (Inherited: 0x28)
struct UINTLPluginObserver : UInterface {

	void OnWebViewResult(struct FINTLWebViewResult Ret); // Function INTLPlugin.INTLPluginObserver.OnWebViewResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbce0a0
	void OnUpdateProgressResult(struct FINTLUpdateProgress Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateProgressResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcdf60
	void OnUpdateNewVersionInfoResult(struct FINTLUpdateNewVersionInfo Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateNewVersionInfoResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcddf0
	void OnUpdateBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateBaseResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcdc30
	void OnShowAccountPicker(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnShowAccountPicker // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcda40
	void OnResetPassword(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnResetPassword // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcd880
	void OnRequestVerifyCode(struct FINTLVerifyCodeStatusResult Ret); // Function INTLPlugin.INTLPluginObserver.OnRequestVerifyCode // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcd6c0
	void OnQueryVerifyCodeStatus(struct FINTLVerifyCodeStatusResult Ret); // Function INTLPlugin.INTLPluginObserver.OnQueryVerifyCodeStatus // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcd500
	void OnQueryUserInfo(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnQueryUserInfo // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcd2f0
	void OnQueryRegisterStatus(struct FINTLRegisterStatusResult Ret); // Function INTLPlugin.INTLPluginObserver.OnQueryRegisterStatus // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcd120
	void OnQueryIsReceiveEmail(struct FINTLIsReceiveEmailResult Ret); // Function INTLPlugin.INTLPluginObserver.OnQueryIsReceiveEmail // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbccf60
	void OnQueryActiveUser(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnQueryActiveUser // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbccda0
	void OnPushResult(struct FINTLPushResult Ret); // Function INTLPlugin.INTLPluginObserver.OnPushResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbccb90
	void OnPushBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnPushBaseResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc9d0
	void OnNoticeRequestData(struct FINTLNoticeResult Ret); // Function INTLPlugin.INTLPluginObserver.OnNoticeRequestData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc710
	void OnNeedRefreshUser(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnNeedRefreshUser // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc550
	void OnModifyProfile(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnModifyProfile // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc390
	void OnModifyAccount(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnModifyAccount // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc1d0
	void OnLogout(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnLogout // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcc010
	void OnLoginWithMappedChannel(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnLoginWithMappedChannel // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcbdf0
	void OnLoginWithBoundChannel(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnLoginWithBoundChannel // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcbbd0
	void OnLogin(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnLogin // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcb9c0
	void OnIPInfoResult(struct FINTLLBSIPInfoResult Ret); // Function INTLPlugin.INTLPluginObserver.OnIPInfoResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcb750
	void OnIDTokenResult(struct FINTLIDTokenResult Ret); // Function INTLPlugin.INTLPluginObserver.OnIDTokenResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcb540
	void OnFriendResult(struct FINTLFriendResult Ret); // Function INTLPlugin.INTLPluginObserver.OnFriendResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcb2c0
	void OnFriendBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnFriendBaseResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcb100
	void OnExtendResult(struct FINTLExtendResult Ret); // Function INTLPlugin.INTLPluginObserver.OnExtendResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcaef0
	void OnDNSResult(struct FINTLDNSResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDNSResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbca770
	void OnDismissLoginUI(bool Canceled); // Function INTLPlugin.INTLPluginObserver.OnDismissLoginUI // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcae60
	void OnDirTreeResult(struct FINTLDirTreeResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDirTreeResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcabe0
	void OnDeviceLevelResult(struct FINTLDeviceLevelResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDeviceLevelResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbcaa20
	void OnCustomerResult(struct FINTLCustomerResult Ret); // Function INTLPlugin.INTLPluginObserver.OnCustomerResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbca5a0
	void OnComplianceResult(struct FINTLComplianceResult Ret); // Function INTLPlugin.INTLPluginObserver.OnComplianceResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbca430
	void OnBuildMapWithLoggedinChannel(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnBuildMapWithLoggedinChannel // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbca210
	void OnBindWithLoggedinChannel(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnBindWithLoggedinChannel // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc9ff0
	void OnBind(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnBind // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc9de0
	void OnAutoLogin(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAutoLogin // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc9bd0
	void OnAuthResult(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAuthResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc99b0
	void OnAuthBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAuthBaseResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc97f0
	void OnAccountResult(struct FINTLAccountResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAccountResult // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbc9640
};

// Class INTLPlugin.INTLSDKAPI
// Size: 0x28 (Inherited: 0x28)
struct UINTLSDKAPI : UBlueprintFunctionLibrary {

	bool UpdateStop(); // Function INTLPlugin.INTLSDKAPI.UpdateStop // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2500
	bool UpdateStart(struct FINTLUpdateInitInfo Info); // Function INTLPlugin.INTLSDKAPI.UpdateStart // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd23b0
	bool UpdateContinue(); // Function INTLPlugin.INTLSDKAPI.UpdateContinue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2380
	bool UpdateConfig(struct TMap<struct FString, struct FString> Cfg, struct FString Project); // Function INTLPlugin.INTLSDKAPI.UpdateConfig // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd21b0
	void UnregisterPush(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.UnregisterPush // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd20d0
	bool ShowAccountPicker(); // Function INTLPlugin.INTLSDKAPI.ShowAccountPicker // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd20a0
	bool Share(struct FINTLFriendReqInfo Info, struct FString Channel); // Function INTLPlugin.INTLSDKAPI.Share // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1590
	void SetTag(struct FString Channel, struct FString Tag); // Function INTLPlugin.INTLSDKAPI.SetTag // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1f30
	void SetDeviceLevel(int32_t Level); // Function INTLPlugin.INTLSDKAPI.SetDeviceLevel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1eb0
	void SetCrashUserValue(struct FString Key, struct FString Value); // Function INTLPlugin.INTLSDKAPI.SetCrashUserValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1d40
	void SetCrashUserId(struct FString UserId); // Function INTLPlugin.INTLSDKAPI.SetCrashUserId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1c60
	void SetAccountInfo(enum class UINTLLoginChannel Channel, int32_t ChannelID, struct FString LangType, int32_t AccountPlatType); // Function INTLPlugin.INTLSDKAPI.SetAccountInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1ad0
	void SetAccount(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.SetAccount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1960
	bool SendMessage(struct FINTLFriendReqInfo Info, struct FString Channel); // Function INTLPlugin.INTLSDKAPI.SendMessage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1590
	bool ResetPasswordWithVerifyCode(struct FString Account, struct FString VerifyCode, struct FString PhoneAreaCode, struct FString NewPassword, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ResetPasswordWithVerifyCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd1270
	bool ResetPasswordWithOldPassword(struct FString Account, struct FString OldPassword, struct FString PhoneAreaCode, struct FString NewPassword, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ResetPasswordWithOldPassword // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0f50
	bool ResetGuest(); // Function INTLPlugin.INTLSDKAPI.ResetGuest // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0f20
	bool RequestVerifyCode(struct FString Account, enum class UVerifyCodeType CodeType, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.RequestVerifyCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0ce0
	void RequestTrackingAuthorization(); // Function INTLPlugin.INTLSDKAPI.RequestTrackingAuthorization // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0cc0
	void RequestIPInfo(); // Function INTLPlugin.INTLSDKAPI.RequestIPInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0ca0
	void ReportPayStep(int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportPayStep // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd09f0
	void ReportLoginStep(int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportLoginStep // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0740
	void ReportException(int32_t Type, struct FString ExceptionName, struct FString ExceptionMsg, struct FString ExceptionStack, struct TMap<struct FString, struct FString> ExtInfo); // Function INTLPlugin.INTLSDKAPI.ReportException // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0400
	void ReportEvent(struct FString EventName, struct TMap<struct FString, struct FString> ParamsMap, struct FString SpecificChannel, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ReportEvent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd0100
	void ReportCustomEventStep(struct FString EventName, int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportCustomEventStep // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcfdb0
	void ReportBinary(struct FString EventName, struct FString Data, int32_t Length, struct FString SpecificChannel); // Function INTLPlugin.INTLSDKAPI.ReportBinary // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcfb80
	void RemoveObserver(struct TScriptInterface<None> Observer); // Function INTLPlugin.INTLSDKAPI.RemoveObserver // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcfaf0
	void RegisterPush(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.RegisterPush // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcf980
	bool Register(struct FString Account, struct FString Password, struct FString VerifyCode, struct FString PhoneAreaCode, struct FINTLAccountProfile userProfile); // Function INTLPlugin.INTLSDKAPI.Register // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcf4d0
	bool QueryVerifyCodeStatus(struct FString Account, struct FString VerifyCode, enum class UVerifyCodeType CodeType, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryVerifyCodeStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcf200
	bool QueryUserInfo(); // Function INTLPlugin.INTLSDKAPI.QueryUserInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcf1d0
	bool QueryRegisterStatus(struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryRegisterStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcefc0
	bool QueryIsReceiveEmail(struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryIsReceiveEmail // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcedb0
	void QueryIpByHost(struct FString Host); // Function INTLPlugin.INTLSDKAPI.QueryIpByHost // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcecd0
	void QueryIDToken(); // Function INTLPlugin.INTLSDKAPI.QueryIDToken // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcecb0
	bool QueryFriends(enum class UINTLLoginChannel Channel, int32_t Page, int32_t Count, bool IsInGame, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryFriends // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbceac0
	void QueryDirTree(int32_t TreeId); // Function INTLPlugin.INTLSDKAPI.QueryDirTree // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcea40
	void QueryDirNode(int32_t TreeId, int32_t NodeId); // Function INTLPlugin.INTLSDKAPI.QueryDirNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce980
	void QueryDeviceLevel(); // Function INTLPlugin.INTLSDKAPI.QueryDeviceLevel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce960
	bool QueryCanBind(int32_t ChannelID, int32_t AccountPlatType, struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryCanBind // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce6e0
	bool QueryActiveUser(); // Function INTLPlugin.INTLSDKAPI.QueryActiveUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce6b0
	void PostNetworkLatencyInSession(int32_t LatencyMs); // Function INTLPlugin.INTLSDKAPI.PostNetworkLatencyInSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce630
	void PostFrameTimeInSession(float DeltaSeconds); // Function INTLPlugin.INTLSDKAPI.PostFrameTimeInSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce5b0
	void OpenUrl(struct FString URL, enum class UINTLWebViewOrientation ScreenOrientation, bool FullScreenEnable, bool EncryptEnable, bool SystemBrowserEnable, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.OpenUrl // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbce320
	bool OnTickEvent(); // Function INTLPlugin.INTLSDKAPI.OnTickEvent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbcdc00
	struct FString NoticeRequestData(struct FString Region, struct FString LangType, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.NoticeRequestData // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc93f0
	bool ModifyProfile(struct FINTLAccountProfile userProfile); // Function INTLPlugin.INTLSDKAPI.ModifyProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc91a0
	bool ModifyAccountWithVerifyCode(struct FString OldAccount, struct FString OldAccountVerifyCode, struct FString OldPhoneAreaCode, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithVerifyCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc8d40
	bool ModifyAccountWithPassword(struct FString OldAccount, struct FString OldPhoneAreaCode, struct FString Password, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithPassword // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc88e0
	bool ModifyAccountWithLoginState(struct FString OldPhoneAreaCode, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithLoginState // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc85c0
	void MarkSessionLoad(struct FString SessionName); // Function INTLPlugin.INTLSDKAPI.MarkSessionLoad // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc84e0
	void MarkSessionClosed(); // Function INTLPlugin.INTLSDKAPI.MarkSessionClosed // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc84c0
	bool Logout(enum class UINTLLoginChannel Channel); // Function INTLPlugin.INTLSDKAPI.Logout // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc8440
	bool LoginWithVerifyCode(enum class UINTLLoginChannel Channel, struct FString Account, struct FString Password, struct FString VerifyCode, struct FString PhoneAreaCode, struct FString PermissionList); // Function INTLPlugin.INTLSDKAPI.LoginWithVerifyCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc80e0
	bool LoginWithPassword(enum class UINTLLoginChannel Channel, struct FString Account, struct FString Password, struct FString PhoneAreaCode, struct FString PermissionList); // Function INTLPlugin.INTLSDKAPI.LoginWithPassword // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7e10
	bool LoginWithMappedChannel(enum class UINTLLoginChannel Channel, struct FString LoginMode, struct FString Permissions); // Function INTLPlugin.INTLSDKAPI.LoginWithMappedChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7c60
	bool LoginWithChannel(enum class UINTLLoginChannel Channel, struct FString LoginMode); // Function INTLPlugin.INTLSDKAPI.LoginWithChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7b30
	bool LoginWithBoundChannel(enum class UINTLLoginChannel Channel, struct FString LoginMode); // Function INTLPlugin.INTLSDKAPI.LoginWithBoundChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7a00
	bool Login(enum class UINTLLoginChannel Channel, struct FString Permissions, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.Login // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7850
	void LogCrashInfo(enum class UINTLCrashLevel Level, struct FString Tag, struct FString Log); // Function INTLPlugin.INTLSDKAPI.LogCrashInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc76b0
	void LaunchLoginUI(); // Function INTLPlugin.INTLSDKAPI.LaunchLoginUI // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7690
	bool LaunchCustomerUI(struct FINTLCustomerUserProfile userProfile); // Function INTLPlugin.INTLSDKAPI.LaunchCustomerUI // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc7040
	bool IsAppInstalled(struct FString Channel, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.IsAppInstalled // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6ed0
	void Init(); // Function INTLPlugin.INTLSDKAPI.Init // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6eb0
	struct FString GetSDKVersion(); // Function INTLPlugin.INTLSDKAPI.GetSDKVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6e30
	struct FString GetIpByHost(struct FString Host); // Function INTLPlugin.INTLSDKAPI.GetIpByHost // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6d00
	struct FString GetInstanceID(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.GetInstanceID // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6bd0
	bool GetIDTokenResult(struct FINTLIDTokenResult jwtRet); // Function INTLPlugin.INTLSDKAPI.GetIDTokenResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbc6ad0
	struct FString GetEncryptUrl(struct FString URL); // Function INTLPlugin.INTLSDKAPI.GetEncryptUrl // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc69a0
	int32_t GetDeviceLevel(); // Function INTLPlugin.INTLSDKAPI.GetDeviceLevel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6970
	struct FString GetCurrentResourceVersion(); // Function INTLPlugin.INTLSDKAPI.GetCurrentResourceVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc68f0
	struct FString GetCurrentAppVersion(); // Function INTLPlugin.INTLSDKAPI.GetCurrentAppVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6870
	bool GetAuthResult(struct FINTLAuthResult LoginRet); // Function INTLPlugin.INTLSDKAPI.GetAuthResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbc6660
	struct FString ExtendInvoke(enum class UINTLLoginChannel Channel, struct FString ExtendMethodName, struct FString ParamsJson); // Function INTLPlugin.INTLSDKAPI.ExtendInvoke // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6470
	void DismissLoginUI(bool Canceled); // Function INTLPlugin.INTLSDKAPI.DismissLoginUI // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc63f0
	void DeleteTag(struct FString Channel, struct FString Tag); // Function INTLPlugin.INTLSDKAPI.DeleteTag // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6280
	void DeleteLocalNotifications(struct FString Key); // Function INTLPlugin.INTLSDKAPI.DeleteLocalNotifications // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc61a0
	void DeleteAccount(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.DeleteAccount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc6030
	bool ComplianceSetUserProfile(struct FString GameID, struct FString OpenId, struct FString Token, int32_t ChannelID, struct FString Region); // Function INTLPlugin.INTLSDKAPI.ComplianceSetUserProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5d60
	void ComplianceSetParentCertificateStatus(enum class UComplianceParentCertificateStatus Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetParentCertificateStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5cf0
	void ComplianceSetEUAgreeStatus(enum class UComplianceAgreeStatus Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetEUAgreeStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5c80
	void ComplianceSetAdulthood(enum class UComplianceAgeStatus Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetAdulthood // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5c10
	void ComplianceSendEmail(struct FString Email, struct FString UserName); // Function INTLPlugin.INTLSDKAPI.ComplianceSendEmail // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5aa0
	void ComplianceQueryUserStatus(); // Function INTLPlugin.INTLSDKAPI.ComplianceQueryUserStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5a80
	void ComplianceCommitBirthday(int32_t BirthdayYear, int32_t BirthdayMonth, int32_t BirthdayDay); // Function INTLPlugin.INTLSDKAPI.ComplianceCommitBirthday // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5980
	void ClearLocalNotifications(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.ClearLocalNotifications // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc58a0
	bool CheckActiveUser(); // Function INTLPlugin.INTLSDKAPI.CheckActiveUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5870
	void CallJS(struct FString JsonJsParam); // Function INTLPlugin.INTLSDKAPI.CallJS // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5790
	bool BuildMapWithLoggedinChannel(); // Function INTLPlugin.INTLSDKAPI.BuildMapWithLoggedinChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5760
	bool BindWithLoggedinChannel(); // Function INTLPlugin.INTLSDKAPI.BindWithLoggedinChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5730
	bool Bind(enum class UINTLLoginChannel Channel, struct FString Permissions, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.Bind // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5580
	bool AutoLogin(); // Function INTLPlugin.INTLSDKAPI.AutoLogin // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5550
	void AddObserver(struct TScriptInterface<None> Observer); // Function INTLPlugin.INTLSDKAPI.AddObserver // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc54c0
	void AddLocalNotificationIOS(struct FString Channel, struct FINTLLocalNotificationIOS LocalNotification); // Function INTLPlugin.INTLSDKAPI.AddLocalNotificationIOS // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc5220
	void AddLocalNotification(struct FString Channel, struct FINTLLocalNotification LocalNotification); // Function INTLPlugin.INTLSDKAPI.AddLocalNotification // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbc4ed0
};

// Class INTLPlugin.INTLUtility
// Size: 0x28 (Inherited: 0x28)
struct UINTLUtility : UBlueprintFunctionLibrary {

	bool Regular(struct FString Str, struct FString Reg); // Function INTLPlugin.INTLUtility.Regular // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2800
	int32_t RefreshCurToastCnt(int32_t ChangeCnt); // Function INTLPlugin.INTLUtility.RefreshCurToastCnt // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2770
	int32_t GetNewToastOrder(); // Function INTLPlugin.INTLUtility.GetNewToastOrder // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2740
	void ForceCrash(); // Function INTLPlugin.INTLUtility.ForceCrash // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbd2720
};

