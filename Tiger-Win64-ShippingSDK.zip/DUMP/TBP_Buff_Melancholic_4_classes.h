// BlueprintGeneratedClass TBP_Buff_Melancholic_4.TBP_Buff_Melancholic_3_C
// Size: 0x270 (Inherited: 0x270)
struct UTBP_Buff_Melancholic_3_C : UTigerBuff {
};

