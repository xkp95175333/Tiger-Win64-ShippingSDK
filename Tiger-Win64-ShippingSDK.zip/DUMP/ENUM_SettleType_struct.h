// UserDefinedEnum ENUM_SettleType.ENUM_SettleType
enum class ENUM_SettleType : uint8 {
	NewEnumerator0,
	NewEnumerator3,
	NewEnumerator4,
	ENUM_MAX,
};

