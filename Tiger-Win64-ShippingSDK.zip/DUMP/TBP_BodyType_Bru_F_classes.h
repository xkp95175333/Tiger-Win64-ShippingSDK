// BlueprintGeneratedClass TBP_BodyType_Bru_F.TBP_BodyType_Bru_F_C
// Size: 0x138 (Inherited: 0x138)
struct UTBP_BodyType_Bru_F_C : UTigerCharacterBodyTypeCustomization {
};

