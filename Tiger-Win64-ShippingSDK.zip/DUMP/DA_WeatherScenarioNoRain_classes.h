// BlueprintGeneratedClass DA_WeatherScenarioNoRain.DA_WeatherScenarioNoRain_C
// Size: 0x70 (Inherited: 0x70)
struct UDA_WeatherScenarioNoRain_C : UDA_WeatherScenario_C {
};

