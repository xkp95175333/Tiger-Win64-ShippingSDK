// BlueprintGeneratedClass SL_Elysium_Johannes.SL_Elysium_Johannes_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_Johannes_C : ALevelScriptActor {
};

