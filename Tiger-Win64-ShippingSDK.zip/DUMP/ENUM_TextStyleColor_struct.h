// UserDefinedEnum ENUM_TextStyleColor.ENUM_TextStyleColor
enum class ENUM_TextStyleColor : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	ENUM_MAX,
};

