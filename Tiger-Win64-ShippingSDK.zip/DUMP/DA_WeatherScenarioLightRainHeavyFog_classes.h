// BlueprintGeneratedClass DA_WeatherScenarioLightRainHeavyFog.DA_WeatherScenarioLightRainHeavyFog_C
// Size: 0x70 (Inherited: 0x70)
struct UDA_WeatherScenarioLightRainHeavyFog_C : UDA_WeatherScenario_C {
};

