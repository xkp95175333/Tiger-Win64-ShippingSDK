// BlueprintGeneratedClass TBP_Buff_Phlegmatic_5.TBP_Buff_Phlegmatic_4_C
// Size: 0x278 (Inherited: 0x278)
struct UTBP_Buff_Phlegmatic_4_C : UTigerBuffHealthRegenBase {
};

