// UserDefinedStruct S_ItemWithProbability.S_ItemWithProbability
// Size: 0x08 (Inherited: 0x00)
struct FS_ItemWithProbability {
	int32_t NumberOfItems_2_EBFA363447F487F4057983A4AD38AB52; // 0x00(0x04)
	float Probability_5_20713BC649CDD075393965BFC6A999C6; // 0x04(0x04)
};

