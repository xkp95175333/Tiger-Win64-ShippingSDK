// BlueprintGeneratedClass TBP_Buff_Sanguine_7.TBP_Buff_Sanguine_6_C
// Size: 0x278 (Inherited: 0x278)
struct UTBP_Buff_Sanguine_6_C : UTigerBuffHealthRegenBase {
};

