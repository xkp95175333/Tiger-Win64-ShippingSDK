// BlueprintGeneratedClass TBP_Buff_KindredCharm_Player.TBP_Buff_KindredCharm_Player_C
// Size: 0x278 (Inherited: 0x270)
struct UTBP_Buff_KindredCharm_Player_C : UTigerBuffKindredCharm {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)

	void OnActivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_KindredCharm_Player.TBP_Buff_KindredCharm_Player_C.OnActivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnDeactivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_KindredCharm_Player.TBP_Buff_KindredCharm_Player_C.OnDeactivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_Buff_KindredCharm_Player(int32_t EntryPoint); // Function TBP_Buff_KindredCharm_Player.TBP_Buff_KindredCharm_Player_C.ExecuteUbergraph_TBP_Buff_KindredCharm_Player // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

