// BlueprintGeneratedClass TBP_BlindingBeauty_Config.TBP_BlindingBeauty_Config_C
// Size: 0x1d8 (Inherited: 0x1d8)
struct UTBP_BlindingBeauty_Config_C : UTigerBlindingBeautyConfig {
};

