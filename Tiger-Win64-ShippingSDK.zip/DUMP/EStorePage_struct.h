// UserDefinedEnum EStorePage.EStorePage
enum class EStorePage : uint8 {
	NewEnumerator0,
	NewEnumerator2,
	NewEnumerator1,
	EStorePage_MAX,
};

