// BlueprintGeneratedClass TBP_BRU_M_HEAD_01_SKINTONE_05.TBP_BRU_M_HEAD_01_SKINTONE_05_C
// Size: 0x160 (Inherited: 0x160)
struct UTBP_BRU_M_HEAD_01_SKINTONE_05_C : UTBP_SkinToneCustomization_Master_C {
};

