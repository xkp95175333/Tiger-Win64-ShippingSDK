// BlueprintGeneratedClass TBP_Buff_HolyincenseShield.TBP_Buff_HolyincenseShield_C
// Size: 0x278 (Inherited: 0x270)
struct UTBP_Buff_HolyincenseShield_C : UTigerBuffUnholyStimulant {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)

	void OnActivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_HolyincenseShield.TBP_Buff_HolyincenseShield_C.OnActivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void OnDeactivated(struct ATigerCharacter* InBuffOwner, struct ATigerCharacter* InBuffCaster); // Function TBP_Buff_HolyincenseShield.TBP_Buff_HolyincenseShield_C.OnDeactivated // (Event|Public|BlueprintEvent) // @ game+0x16a87a0
	void ExecuteUbergraph_TBP_Buff_HolyincenseShield(int32_t EntryPoint); // Function TBP_Buff_HolyincenseShield.TBP_Buff_HolyincenseShield_C.ExecuteUbergraph_TBP_Buff_HolyincenseShield // (Final|UbergraphFunction|HasDefaults) // @ game+0x16a87a0
};

